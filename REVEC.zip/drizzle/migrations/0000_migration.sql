CREATE TABLE public.datasets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  filename text NOT NULL,
  text_column text NOT NULL,
  row_count int NOT NULL DEFAULT 0,
  excluded_count int NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'uploaded',
  error text,
  result jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.datasets TO authenticated;
GRANT ALL ON public.datasets TO service_role;
ALTER TABLE public.datasets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own datasets select" ON public.datasets FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own datasets insert" ON public.datasets FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own datasets update" ON public.datasets FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own datasets delete" ON public.datasets FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.feedback_rows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dataset_id uuid NOT NULL REFERENCES public.datasets(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  source_id text NOT NULL,
  position int NOT NULL,
  text text NOT NULL,
  rating numeric,
  sentiment text,
  sentiment_score numeric,
  keywords text[] NOT NULL DEFAULT '{}',
  UNIQUE (dataset_id, source_id)
);
CREATE INDEX feedback_rows_dataset_idx ON public.feedback_rows(dataset_id, position);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.feedback_rows TO authenticated;
GRANT ALL ON public.feedback_rows TO service_role;
ALTER TABLE public.feedback_rows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own rows select" ON public.feedback_rows FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own rows insert" ON public.feedback_rows FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.datasets d WHERE d.id = dataset_id AND d.user_id = auth.uid()));
CREATE POLICY "own rows update" ON public.feedback_rows FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own rows delete" ON public.feedback_rows FOR DELETE TO authenticated USING (auth.uid() = user_id);